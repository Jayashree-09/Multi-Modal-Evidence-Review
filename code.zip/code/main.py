"""
Multi-Modal Damage Claim Verification System
HackerRank Orchestrate June '26

Entry point: processes dataset/claims.csv and writes output.csv
"""

import os
import sys
import csv
import json
import base64
import time
import logging
from pathlib import Path

import anthropic

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────────────
MODEL = "claude-sonnet-4-6"          # vision + text, good balance of cost/quality
MAX_TOKENS = 1024
MAX_RETRIES = 3
RETRY_DELAY = 10                      # seconds; back-off on rate-limit

ALLOWED_ISSUE_TYPES = [
    "dent", "scratch", "crack", "glass_shatter", "broken_part",
    "missing_part", "torn_packaging", "crushed_packaging",
    "water_damage", "stain", "none", "unknown",
]
ALLOWED_CLAIM_STATUS = ["supported", "contradicted", "not_enough_information"]
ALLOWED_SEVERITY = ["none", "low", "medium", "high", "unknown"]
ALLOWED_RISK_FLAGS = [
    "none", "blurry_image", "cropped_or_obstructed", "low_light_or_glare",
    "wrong_angle", "wrong_object", "wrong_object_part", "damage_not_visible",
    "claim_mismatch", "possible_manipulation", "non_original_image",
    "text_instruction_present", "user_history_risk", "manual_review_required",
]
CAR_PARTS = [
    "front_bumper", "rear_bumper", "door", "hood", "windshield", "side_mirror",
    "headlight", "taillight", "fender", "quarter_panel", "body", "unknown",
]
LAPTOP_PARTS = [
    "screen", "keyboard", "trackpad", "hinge", "lid", "corner", "port",
    "base", "body", "unknown",
]
PACKAGE_PARTS = [
    "box", "package_corner", "package_side", "seal", "label",
    "contents", "item", "unknown",
]

OUTPUT_COLS = [
    "user_id", "image_paths", "user_claim", "claim_object",
    "evidence_standard_met", "evidence_standard_met_reason",
    "risk_flags", "issue_type", "object_part", "claim_status",
    "claim_status_justification", "supporting_image_ids", "valid_image", "severity",
]

# ── Helpers ──────────────────────────────────────────────────────────────────

def load_csv(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def encode_image(image_path: str) -> tuple[str, str]:
    """Return (base64_data, media_type) for an image file."""
    ext = Path(image_path).suffix.lower()
    media_map = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp",
    }
    media_type = media_map.get(ext, "image/jpeg")
    with open(image_path, "rb") as f:
        return base64.standard_b64encode(f.read()).decode("utf-8"), media_type


def image_id_from_path(path: str) -> str:
    return Path(path).stem


def load_user_history(history_path: str) -> dict:
    rows = load_csv(history_path)
    return {r["user_id"]: r for r in rows}


def load_evidence_requirements(req_path: str) -> list[dict]:
    return load_csv(req_path)


def get_user_risk_context(user_id: str, history: dict) -> str:
    h = history.get(user_id)
    if not h:
        return "No prior claim history found for this user."
    return (
        f"Past claims: {h.get('past_claim_count', 0)} total "
        f"({h.get('accept_claim', 0)} accepted, "
        f"{h.get('manual_review_claim', 0)} manual review, "
        f"{h.get('rejected_claim', 0)} rejected). "
        f"Last 90 days: {h.get('last_90_days_claim_count', 0)} claims. "
        f"History flags: {h.get('history_flags', 'none')}. "
        f"Summary: {h.get('history_summary', 'N/A')}"
    )


def get_evidence_requirements(claim_object: str, requirements: list[dict]) -> str:
    relevant = [
        r for r in requirements
        if r["claim_object"] in (claim_object, "all")
    ]
    if not relevant:
        return "No specific evidence requirements found."
    lines = []
    for r in relevant:
        lines.append(
            f"[{r['requirement_id']}] ({r['applies_to']}): {r['minimum_image_evidence']}"
        )
    return "\n".join(lines)


def build_parts_list(claim_object: str) -> str:
    if claim_object == "car":
        return ", ".join(CAR_PARTS)
    if claim_object == "laptop":
        return ", ".join(LAPTOP_PARTS)
    return ", ".join(PACKAGE_PARTS)


def build_prompt(row: dict, user_risk: str, evidence_reqs: str) -> str:
    claim_object = row["claim_object"]
    parts_list = build_parts_list(claim_object)
    return f"""You are a damage-claim verification AI.
Your job is to analyse the submitted images and evaluate whether they support, contradict, or provide insufficient evidence for the user's damage claim.

## Claim context
- Claim object: {claim_object}
- User claim conversation: {row["user_claim"]}

## User history
{user_risk}

## Evidence requirements for this object type
{evidence_reqs}

## Your task
Carefully examine every image. Then produce a JSON object (no markdown fences, raw JSON only) with EXACTLY these keys:

{{
  "evidence_standard_met": true | false,
  "evidence_standard_met_reason": "short reason",
  "risk_flags": ["flag1", "flag2"],   // from allowed list; use ["none"] if clean
  "issue_type": "one of allowed values",
  "object_part": "one of allowed values for {claim_object}",
  "claim_status": "supported | contradicted | not_enough_information",
  "claim_status_justification": "concise image-grounded explanation mentioning image IDs",
  "supporting_image_ids": ["img_1", "img_2"],  // or ["none"]
  "valid_image": true | false,
  "severity": "none | low | medium | high | unknown"
}}

## Allowed values
issue_type: {', '.join(ALLOWED_ISSUE_TYPES)}
object_part (for {claim_object}): {parts_list}
claim_status: supported, contradicted, not_enough_information
severity: none, low, medium, high, unknown
risk_flags: {', '.join(ALLOWED_RISK_FLAGS)}

## Rules
- Images are the PRIMARY source of truth.
- User history adds risk context but cannot override clear visual evidence.
- If images are unusable (blurry, wrong object, etc.) set valid_image=false and evidence_standard_met=false.
- supporting_image_ids should list only image IDs that directly support your decision.
- Be concise but specific in justifications — reference image IDs.
- Return ONLY the JSON object, no other text.
"""


def call_claude(client: anthropic.Anthropic, prompt: str, image_data: list[dict]) -> dict:
    """Call Claude with text + images, return parsed JSON result."""
    content = []
    for img in image_data:
        content.append({
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": img["media_type"],
                "data": img["data"],
            },
        })
        content.append({"type": "text", "text": f"[Image ID: {img['image_id']}]"})
    content.append({"type": "text", "text": prompt})

    for attempt in range(MAX_RETRIES):
        try:
            response = client.messages.create(
                model=MODEL,
                max_tokens=MAX_TOKENS,
                messages=[{"role": "user", "content": content}],
            )
            raw = response.content[0].text.strip()
            # Strip possible markdown fences
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            return json.loads(raw)
        except anthropic.RateLimitError:
            wait = RETRY_DELAY * (attempt + 1)
            log.warning("Rate limit hit, waiting %ds (attempt %d/%d)", wait, attempt + 1, MAX_RETRIES)
            time.sleep(wait)
        except json.JSONDecodeError as e:
            log.error("JSON parse error on attempt %d: %s", attempt + 1, e)
            if attempt == MAX_RETRIES - 1:
                return {}
        except Exception as e:
            log.error("API error on attempt %d: %s", attempt + 1, e)
            if attempt == MAX_RETRIES - 1:
                return {}
        time.sleep(2)
    return {}


def safe_value(val, allowed: list, default: str) -> str:
    if isinstance(val, list):
        val = val[0] if val else default
    return val if val in allowed else default


def safe_flags(flags) -> str:
    if not flags:
        return "none"
    if isinstance(flags, str):
        flags = [f.strip() for f in flags.split(";")]
    valid = [f for f in flags if f in ALLOWED_RISK_FLAGS]
    return ";".join(valid) if valid else "none"


def safe_image_ids(ids) -> str:
    if not ids:
        return "none"
    if isinstance(ids, list):
        return ";".join(ids) if ids and ids != ["none"] else "none"
    return ids


def coerce_bool(val) -> str:
    if isinstance(val, bool):
        return str(val).lower()
    if isinstance(val, str):
        return "true" if val.lower() == "true" else "false"
    return "false"


def make_fallback_row(row: dict) -> dict:
    """Return a safe fallback output row when processing fails."""
    return {
        "user_id": row["user_id"],
        "image_paths": row["image_paths"],
        "user_claim": row["user_claim"],
        "claim_object": row["claim_object"],
        "evidence_standard_met": "false",
        "evidence_standard_met_reason": "Processing error; manual review required.",
        "risk_flags": "manual_review_required",
        "issue_type": "unknown",
        "object_part": "unknown",
        "claim_status": "not_enough_information",
        "claim_status_justification": "System could not process this claim. Manual review required.",
        "supporting_image_ids": "none",
        "valid_image": "false",
        "severity": "unknown",
    }


def process_row(
    client: anthropic.Anthropic,
    row: dict,
    base_dir: str,
    user_history: dict,
    evidence_reqs: list[dict],
) -> dict:
    user_id = row["user_id"]
    image_paths_str = row.get("image_paths", "")
    paths = [p.strip() for p in image_paths_str.split(";") if p.strip()]

    # Load images
    image_data = []
    missing_images = []
    for p in paths:
        full_path = os.path.join(base_dir, p)
        if not os.path.exists(full_path):
            log.warning("Image not found: %s", full_path)
            missing_images.append(p)
            continue
        try:
            data, media_type = encode_image(full_path)
            image_data.append({
                "image_id": image_id_from_path(p),
                "data": data,
                "media_type": media_type,
            })
        except Exception as e:
            log.error("Failed to encode image %s: %s", p, e)
            missing_images.append(p)

    if not image_data:
        log.warning("No usable images for user %s", user_id)
        out = make_fallback_row(row)
        out["evidence_standard_met_reason"] = "No valid images could be loaded."
        return out

    user_risk = get_user_risk_context(user_id, user_history)
    evidence_reqs_text = get_evidence_requirements(row["claim_object"], evidence_reqs)
    prompt = build_prompt(row, user_risk, evidence_reqs_text)

    result = call_claude(client, prompt, image_data)
    if not result:
        return make_fallback_row(row)

    # Add user_history_risk flag if history suggests it
    h = user_history.get(user_id, {})
    risk_flags_list = result.get("risk_flags", [])
    if isinstance(risk_flags_list, str):
        risk_flags_list = [risk_flags_list]
    
    try:
        rejected = int(h.get("rejected_claim", 0))
        last_90 = int(h.get("last_90_days_claim_count", 0))
    except (ValueError, TypeError):
        rejected = 0
        last_90 = 0

    hist_flags = h.get("history_flags", "none")
    if rejected > 2 or last_90 > 3 or (hist_flags and hist_flags != "none"):
        if "user_history_risk" not in risk_flags_list:
            risk_flags_list.append("user_history_risk")
        if "manual_review_required" not in risk_flags_list:
            risk_flags_list.append("manual_review_required")

    return {
        "user_id": user_id,
        "image_paths": image_paths_str,
        "user_claim": row["user_claim"],
        "claim_object": row["claim_object"],
        "evidence_standard_met": coerce_bool(result.get("evidence_standard_met", False)),
        "evidence_standard_met_reason": result.get("evidence_standard_met_reason", "unknown"),
        "risk_flags": safe_flags(risk_flags_list),
        "issue_type": safe_value(result.get("issue_type"), ALLOWED_ISSUE_TYPES, "unknown"),
        "object_part": result.get("object_part", "unknown"),
        "claim_status": safe_value(result.get("claim_status"), ALLOWED_CLAIM_STATUS, "not_enough_information"),
        "claim_status_justification": result.get("claim_status_justification", ""),
        "supporting_image_ids": safe_image_ids(result.get("supporting_image_ids")),
        "valid_image": coerce_bool(result.get("valid_image", False)),
        "severity": safe_value(result.get("severity"), ALLOWED_SEVERITY, "unknown"),
    }


def write_output(rows: list[dict], output_path: str):
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=OUTPUT_COLS)
        writer.writeheader()
        writer.writerows(rows)
    log.info("Written %d rows to %s", len(rows), output_path)


# ── Main ─────────────────────────────────────────────────────────────────────

def run(
    dataset_dir: str = "dataset",
    input_csv: str = None,
    output_csv: str = "output.csv",
):
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        sys.exit("ANTHROPIC_API_KEY environment variable not set.")

    client = anthropic.Anthropic(api_key=api_key)

    if input_csv is None:
        input_csv = os.path.join(dataset_dir, "claims.csv")

    history_csv = os.path.join(dataset_dir, "user_history.csv")
    evidence_csv = os.path.join(dataset_dir, "evidence_requirements.csv")

    log.info("Loading data files…")
    claims = load_csv(input_csv)
    user_history = load_user_history(history_csv)
    evidence_reqs = load_evidence_requirements(evidence_csv)

    log.info("Processing %d claims…", len(claims))
    results = []
    for i, row in enumerate(claims, 1):
        log.info("[%d/%d] Processing claim for user %s", i, len(claims), row["user_id"])
        try:
            out_row = process_row(client, row, dataset_dir, user_history, evidence_reqs)
        except Exception as e:
            log.error("Unexpected error for row %d: %s", i, e)
            out_row = make_fallback_row(row)
        results.append(out_row)
        # Throttle: ~10 RPM comfortable buffer for Sonnet
        if i < len(claims):
            time.sleep(1.5)

    write_output(results, output_csv)
    return results


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Damage Claim Verifier")
    parser.add_argument("--dataset-dir", default="dataset", help="Root dataset directory")
    parser.add_argument("--input-csv", default=None, help="Override input CSV path")
    parser.add_argument("--output-csv", default="output.csv", help="Output CSV path")
    args = parser.parse_args()

    run(
        dataset_dir=args.dataset_dir,
        input_csv=args.input_csv,
        output_csv=args.output_csv,
    )
